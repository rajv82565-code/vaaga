(() => {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const touch = matchMedia("(hover: none)").matches;
  const u = (n) => `images/estrella-${n}.jpg`;

  const AUCTIONS = [
    { t: "Thiruvathira", a: "Group · On Stage", bid: "Classical Roots", img: "08" },
    { t: "Mohiniyattam", a: "Solo · On Stage", bid: "Grace in Motion", img: "06" },
    { t: "Battle of Bands", a: "Group · On Stage", bid: "Turn It Up", img: "05" },
    { t: "Street Dance", a: "Group · On Stage", bid: "Own the Floor", img: "11" },
    { t: "Mappila Pattu", a: "Solo · On Stage", bid: "Voice of Malabar", img: "12" },
    { t: "Canvas Live", a: "Solo · Off Stage", bid: "Paint the Moment", img: "09" },
  ];

  // Graceful fallback if any remote image fails: generative gradient artwork
  const fallback = (seed) => {
    const h = (seed * 67) % 360;
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='hsl(${h},80%,60%)'/><stop offset='1' stop-color='hsl(${(h + 140) % 360},70%,30%)'/></linearGradient><filter id='n'><feTurbulence baseFrequency='0.012' numOctaves='3' seed='${seed}'/><feDisplacementMap in='SourceGraphic' scale='120'/></filter></defs><rect width='400' height='400' fill='url(#g)'/><circle cx='200' cy='200' r='120' fill='hsl(${(h + 60) % 360},90%,70%)' filter='url(#n)' opacity='.85'/></svg>`;
    return "data:image/svg+xml," + encodeURIComponent(svg);
  };
  let seed = 1;
  const guard = (img) => {
    const s = seed++;
    img.addEventListener("error", () => { img.src = fallback(s); }, { once: true });
  };
  $$("img").forEach(guard);

  /* ---------- Build auction cards ---------- */
  const track = $("#track");
  AUCTIONS.forEach((x, i) => {
    const el = document.createElement("article");
    el.className = "card";
    el.dataset.cursor = "Join";
    el.innerHTML = `
      <div class="card__img">
        <img alt="${x.t}, ${x.a}" loading="lazy" draggable="false" src="${u(x.img)}" />
        <span class="card__lot">EVENT ${String(i + 1).padStart(2, "0")}</span>
        <span class="card__bid">${x.bid}</span>
      </div>
      <div class="card__meta">
        <div><h3>${x.t}</h3><p>${x.a}</p></div>
        <i>↗</i>
      </div>`;
    guard($("img", el));
    track.appendChild(el);
  });

  /* ---------- Split text ---------- */
  $$("[data-split]").forEach((el) => {
    let i = 0;
    const walk = (node) => {
      [...node.childNodes].forEach((n) => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach((part) => {
            if (!part) return;
            if (/^\s+$/.test(part)) return frag.appendChild(document.createTextNode(" "));
            const w = document.createElement("span");
            w.className = "w";
            w.innerHTML = `<span style="--i:${i++}">${part}</span>`;
            frag.appendChild(w);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1) walk(n);
      });
    };
    walk(el);
  });
  $$(".loader__word span, .footer__word span").forEach((s, i, all) => s.style.setProperty("--i", i % 8));

  /* ---------- Preloader ---------- */
  const countEl = $("#loaderCount");
  const start = performance.now();
  const DUR = reduced ? 200 : 1500;
  const tickLoader = (now) => {
    const p = clamp((now - start) / DUR, 0, 1);
    countEl.textContent = Math.round((1 - Math.pow(1 - p, 3)) * 100);
    if (p < 1) return requestAnimationFrame(tickLoader);
    $(".loader").classList.add("is-done");
    document.body.classList.remove("is-loading");
    setTimeout(() => document.body.classList.add("is-ready"), 350);
    // Once the headline has risen, stop clipping its lines so the text-shadow isn't cut into a hard box
    setTimeout(() => document.body.classList.add("is-intro-done"), 350 + 1600);
  };
  requestAnimationFrame(tickLoader);

  /* ---------- Pointer ---------- */
  const mouse = { x: innerWidth / 2, y: innerHeight / 2, nx: 0, ny: 0 };
  addEventListener("pointermove", (e) => {
    mouse.x = e.clientX; mouse.y = e.clientY;
    mouse.nx = e.clientX / innerWidth - 0.5;
    mouse.ny = e.clientY / innerHeight - 0.5;
  });

  const cursor = $(".cursor");
  const cur = { x: mouse.x, y: mouse.y };
  const label = $(".cursor__label");
  document.addEventListener("pointerover", (e) => {
    const view = e.target.closest("[data-cursor]");
    const link = e.target.closest("a, button");
    cursor.classList.toggle("is-view", !!view);
    cursor.classList.toggle("is-hover", !view && !!link);
    if (view) label.textContent = view.dataset.cursor;
  });

  /* ---------- Hero figure: the Theyyam portrait assembles itself out of embers ----------
     Instead of a static <img>, the artwork is sampled into thousands of coloured cells.
     Near-black background pixels are skipped by luminance, so only the lit face, gold
     ornaments and headdress become particles — no manual cutout needed. On load they
     fly in from a scatter and settle into the portrait; once settled they flicker like
     embers, and a small fraction continually break away and drift upward before fading,
     looping forever. */
  const heroFigureWrap = $("#heroFigure");
  const figureCanvas = $("#figureCanvas");
  let figureLoopFn = null;
  if (heroFigureWrap && figureCanvas) {
    const fctx = figureCanvas.getContext("2d");
    const portrait = new Image();
    portrait.src = "images/theyyam-deity.png";

    const WORK_W = 170; // sampling resolution — higher = more particles, more cost
    const SAMPLE = touch || innerWidth < 640 ? 3 : innerWidth < 1100 ? 2 : 2;

    let particles = [];
    let fw = 0, fh = 0;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    let ready = false;
    let startT = 0;

    const buildParticles = () => {
      const ratio = portrait.naturalHeight / portrait.naturalWidth || 1.2;
      const workH = Math.round(WORK_W * ratio);
      const off = document.createElement("canvas");
      off.width = WORK_W; off.height = workH;
      const octx = off.getContext("2d");
      octx.drawImage(portrait, 0, 0, WORK_W, workH);
      let data;
      try { data = octx.getImageData(0, 0, WORK_W, workH).data; }
      catch { return; } // e.g. blocked by CORS if hosted cross-origin
      particles = [];
      for (let y = 0; y < workH; y += SAMPLE) {
        for (let x = 0; x < WORK_W; x += SAMPLE) {
          const i = (y * WORK_W + x) * 4;
          const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
          const lum = r * 0.299 + g * 0.587 + b * 0.114;
          if (a < 40 || lum < 24) continue; // skip transparent / near-black background
          particles.push({
            tx: x / WORK_W, ty: y / workH,
            r, g, b,
            x: 0, y: 0, px: 0, py: 0,
            seed: Math.random() * Math.PI * 2,
            drift: 0.5 + Math.random() * 0.9,
            ember: Math.random() < 0.045,
            life: Math.random(),
          });
        }
      }
    };

    const sizeFigure = () => {
      const rect = heroFigureWrap.getBoundingClientRect();
      fw = rect.width; fh = rect.height;
      if (!fw || !fh) return;
      figureCanvas.width = fw * dpr; figureCanvas.height = fh * dpr;
      figureCanvas.style.width = fw + "px"; figureCanvas.style.height = fh + "px";
      fctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (!ready) return;
      const ratio = portrait.naturalWidth / (portrait.naturalHeight || 1);
      let drawH = fh * 0.98, drawW = drawH * ratio;
      if (drawW > fw * 0.98) { drawW = fw * 0.98; drawH = drawW / ratio; }
      const ox = (fw - drawW) / 2, oy = fh - drawH;
      particles.forEach((p) => {
        p.px = ox + p.tx * drawW;
        p.py = oy + p.ty * drawH;
        if (!p.placed) {
          const ang = Math.random() * Math.PI * 2;
          const dist = 160 + Math.random() * 280;
          p.x = p.px + Math.cos(ang) * dist;
          p.y = p.py + Math.sin(ang) * dist + 90;
          p.placed = true;
        }
      });
    };

    portrait.onload = () => {
      buildParticles();
      ready = true;
      sizeFigure();
      startT = performance.now();
    };
    portrait.onerror = () => { /* leave canvas empty — page still works without the artwork */ };

    let pmx = 0, pmy = 0;
    figureLoopFn = (t) => {
      if (!ready || !fw || !particles.length) return;
      const el = t - startT;
      const introP = reduced ? 1 : clamp(el / 1900, 0, 1);
      const introE = 1 - Math.pow(1 - introP, 3);

      pmx = lerp(pmx, mouse.nx * 16, 0.06);
      pmy = lerp(pmy, mouse.ny * 10, 0.06);

      fctx.clearRect(0, 0, fw, fh);
      const cell = Math.max(1.6, (fw / WORK_W) * SAMPLE * 1.05);
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        let x = lerp(p.x, p.px, introE);
        let y = lerp(p.y, p.py, introE);
        let alpha = 0.85;

        if (introP >= 1) {
          const w = Math.sin(el * 0.0011 * p.drift + p.seed);
          x += w * 1.3 + pmx;
          y += Math.cos(el * 0.0009 * p.drift + p.seed) * 1 + pmy;
          alpha = 0.65 + w * 0.22;
          if (p.ember && !reduced) {
            p.life += 0.0055 * p.drift;
            if (p.life > 1) p.life -= 1;
            y -= p.life * 48;
            x += Math.sin(p.life * 6 + p.seed) * 6;
            alpha = (1 - p.life) * 0.9;
          }
        }
        fctx.fillStyle = `rgba(${p.r},${p.g},${p.b},${alpha.toFixed(2)})`;
        fctx.fillRect(x, y, cell, cell);
      }
    };

    let figResizeQueued = false;
    addEventListener("resize", () => {
      if (figResizeQueued) return;
      figResizeQueued = true;
      requestAnimationFrame(() => { figResizeQueued = false; sizeFigure(); });
    });
  }

  /* ---------- Scroll state ---------- */
  let scrollY = window.scrollY, lastY = scrollY, velocity = 0;
  const nav = $(".nav");
  addEventListener("scroll", () => {
    scrollY = window.scrollY;
    nav.classList.toggle("is-scrolled", scrollY > 40);
    nav.classList.toggle("is-hidden", scrollY > lastY && scrollY > innerHeight * 0.8 && !document.body.classList.contains("menu-open"));
    lastY = scrollY;
  }, { passive: true });

  const heroContent = $(".hero__content");
  // Where supported, the headline's scroll-out runs as a CSS scroll-driven animation on the compositor (no main-thread lag)
  const cssHero = !reduced && !!window.CSS?.supports?.("animation-timeline: scroll()");
  let heroLast = -1;

  /* ---------- Cached geometry (avoid layout reads inside the rAF loop) ---------- */
  const speedEls = $$("[data-speed]").map((el) => ({ el, speed: parseFloat(el.dataset.speed), top: 0, h: 0 }));
  let vh = innerHeight;
  const measure = () => {
    vh = innerHeight;
    const sy = window.scrollY;
    speedEls.forEach((s) => {
      const r = s.el.parentElement.getBoundingClientRect();
      s.top = r.top + sy; s.h = r.height;
    });
    maxXCache = Math.max(0, track.scrollWidth - carousel.clientWidth + 24);
    const gr = gallery.getBoundingClientRect();
    gal.top = gr.top + sy; gal.run = Math.max(1, gr.height - vh);
    const rr = reel.getBoundingClientRect();
    rl.top = rr.top + sy; rl.run = Math.max(1, rr.height - vh);
    rl.fw = frame.offsetWidth; rl.fh = frame.offsetHeight; // untransformed size
    rl.ww = words.map((w) => w.offsetWidth);
    rl.narrow = innerWidth <= 900;
    rl.pad = clamp(innerWidth * 0.034, 16, 48);
    rlLast = -1;
  };
  let maxXCache = 0;
  const gallery = $("#gallery");
  const gal = { top: 0, run: 1 };
  const reel = $("#aboutReel");
  const frame = $("#aboutFrame");
  const words = $$(".about__word");
  const rl = { top: 0, run: 1, fw: 0, fh: 0, ww: [0, 0], narrow: false, pad: 16 };
  let rlLast = -1;
  let measureQueued = false;
  const queueMeasure = () => {
    if (measureQueued) return;
    measureQueued = true;
    requestAnimationFrame(() => { measureQueued = false; measure(); });
  };
  // Mobile browsers fire resize while the URL bar slides in/out during scroll; re-laying out then makes the hero jump
  let lastW = innerWidth;
  addEventListener("resize", () => {
    if (touch && innerWidth === lastW && Math.abs(innerHeight - vh) < 160) return;
    lastW = innerWidth;
    queueMeasure();
  });
  addEventListener("load", queueMeasure);
  if ("ResizeObserver" in window) new ResizeObserver(queueMeasure).observe(document.body);
  document.fonts?.ready.then(queueMeasure);

  /* ---------- Main loop ---------- */
  let prevT = performance.now(), prevScroll = scrollY, smoothY = scrollY;
  const loop = (t) => {
    const dt = Math.min(0.05, (t - prevT) / 1000);
    prevT = t;

    const sv = (scrollY - prevScroll) / Math.max(dt, 0.001);
    prevScroll = scrollY;
    velocity = lerp(velocity, clamp(Math.abs(sv), 0, 3000), 0.08);

    // Eased scroll value for scroll-linked motion (framerate independent)
    smoothY = lerp(smoothY, scrollY, 1 - Math.pow(0.001, dt * 1.2));
    if (Math.abs(smoothY - scrollY) < 0.1) smoothY = scrollY;

    // Headline scroll-out follows the real scroll position (smoothing it made the text trail behind, most visibly on the way back up)
    if (!cssHero && (scrollY < vh * 1.2 || heroLast !== 1)) {
      const p = clamp(scrollY / vh, 0, 1);
      if (p !== heroLast) {
        heroLast = p;
        heroContent.style.transform = `translate3d(0,${(p * 120).toFixed(2)}px,0) scale(${(1 - p * 0.12).toFixed(4)})`;
        heroContent.style.opacity = Math.max(0, 1 - p * 1.3).toFixed(3);
      }
    }

    if (figureLoopFn && scrollY < vh * 1.3) figureLoopFn(t);

    // Parallax (pure math on cached positions — no getBoundingClientRect per frame)
    speedEls.forEach((s) => {
      const top = s.top - smoothY;
      if (top + s.h < -200 || top > vh + 200) return;
      const d = top + s.h / 2 - vh / 2;
      s.el.style.transform = `translate3d(0,${(d * s.speed).toFixed(2)}px,0)`;
    });

    // Cursor
    cur.x = lerp(cur.x, mouse.x, 0.2);
    cur.y = lerp(cur.y, mouse.y, 0.2);
    cursor.style.transform = `translate3d(${cur.x}px,${cur.y}px,0)`;

    carouselTick();
    galleryTick();
    reelTick(t);
    requestAnimationFrame(loop);
  };

  /* ---------- About reel ---------- */
  const video = $("#aboutVideo");
  const glow = $("#aboutGlow");
  const gctx = glow.getContext("2d");
  const soundBtn = $("#aboutSound");
  const soundTxt = $("b", soundBtn);
  if ("filter" in gctx) gctx.filter = "blur(3px)"; else glow.classList.add("is-soft");
  let reelSeen = false, glowT = 0;

  // Grows from when the reel is half on screen until ~60% through the pin, then holds full size
  const reelTick = (t) => {
    const start = rl.top - vh * 0.5;
    const inView = smoothY > rl.top - vh && smoothY < rl.top + rl.run + vh;
    const p = reduced ? 1 : clamp((smoothY - start) / (vh * 0.5 + rl.run * 0.6), 0, 1);

    if (inView && !video.paused && t - glowT > 66) { // ~15fps is plenty for a blurred glow
      glowT = t;
      gctx.drawImage(video, 0, 0, glow.width, glow.height);
    }
    if (Math.abs(p - rlLast) < 0.0005) return;
    rlLast = p;

    const e = p < 0.5 ? 4 * p * p * p : 1 - Math.pow(2 - 2 * p, 3) / 2; // ease in-out
    const s = 0.42 + 0.58 * e;
    frame.style.transform = `scale(${s.toFixed(4)})`;
    frame.style.setProperty("--p", e.toFixed(3));
    glow.style.opacity = (e * 0.9).toFixed(3);

    if (rl.narrow) {
      const oy = (rl.fh * s) / 2 + 14;
      words[0].style.transform = `translate3d(-50%, calc(-100% - ${oy.toFixed(1)}px), 0)`;
      words[1].style.transform = `translate3d(-50%, ${oy.toFixed(1)}px, 0)`;
    } else {
      // Hug the frame's edges; once it outgrows the gap they stop at the page margin and blend over it
      words.forEach((w, i) => {
        const o = Math.min((rl.fw * s) / 2 + 28, innerWidth / 2 - rl.pad - rl.ww[i]);
        w.style.transform = `translate3d(${(i ? o : -o).toFixed(1)}px, -50%, 0)`;
      });
    }
  };

  const setSound = (on) => {
    video.muted = !on;
    frame.classList.toggle("is-on", on);
    soundBtn.setAttribute("aria-pressed", on);
    soundTxt.textContent = on ? "Sound on" : "Sound off";
    frame.dataset.cursor = on ? "Mute" : "Sound on";
    if (cursor.classList.contains("is-view")) label.textContent = frame.dataset.cursor;
  };
  if (reduced) soundTxt.textContent = "Play";
  frame.addEventListener("click", () => {
    if (video.paused) { reelSeen = true; video.play().catch(() => { }); setSound(true); return; }
    setSound(video.muted);
  });

  // Only decode while the reel is on screen; reduced-motion visitors start it themselves
  new IntersectionObserver(([e]) => {
    if (e.isIntersecting && (!reduced || reelSeen)) video.play().catch(() => { });
    else if (!e.isIntersecting) video.pause();
  }, { threshold: 0.1 }).observe(frame);

  /* ---------- Carousel ---------- */
  const carousel = $("#carousel");
  const progress = $("#progress");
  let cx = 0, tx = 0, drag = null, moved = 0;
  const maxX = () => maxXCache;
  const step = () => (track.children[0]?.getBoundingClientRect().width || 300) + 10;
  $("#next").addEventListener("click", () => { tx = clamp(tx + step(), 0, maxX()); });
  $("#prev").addEventListener("click", () => { tx = clamp(tx - step(), 0, maxX()); });
  carousel.addEventListener("pointerdown", (e) => {
    drag = { x: e.clientX, start: tx }; moved = 0;
    carousel.classList.add("is-drag");
    carousel.setPointerCapture(e.pointerId);
  });
  carousel.addEventListener("pointermove", (e) => {
    if (!drag) return;
    moved = Math.abs(e.clientX - drag.x);
    tx = clamp(drag.start - (e.clientX - drag.x) * 1.3, -80, maxX() + 80);
  });
  const endDrag = () => { if (!drag) return; drag = null; carousel.classList.remove("is-drag"); tx = clamp(tx, 0, maxX()); };
  carousel.addEventListener("pointerup", endDrag);
  carousel.addEventListener("pointercancel", endDrag);
  carousel.addEventListener("click", (e) => { if (moved > 6) e.preventDefault(); }, true);
  const carouselTick = () => {
    if (Math.abs(tx - cx) < 0.05) return; // settled — skip style writes
    cx = lerp(cx, tx, 0.1);
    track.style.transform = `translate3d(${-cx}px,0,0)`;
    const m = maxX() || 1;
    progress.style.transform = `scaleX(${0.2 + 0.8 * clamp(cx / m, 0, 1)})`;
  };

  /* ---------- Pinned gallery ---------- */
  // Section is sticky for (n-1) screens of scroll; progress 0→1 across that run wipes each pair of photos in over the last
  const galItems = $$(".gallery__item").map((el) => ({ el, figs: $$(".gallery__fig", el).map((f) => ({ el: f, img: $("img", f) })) }));
  const galIdx = $("#galleryIdx");
  const galBar = $("#galleryBar");
  const galTexts = $$(".gallery__text");
  const galList = $$(".gallery__list li");
  let galLast = -1, galShown = -1;
  const galleryTick = () => {
    const p = clamp((smoothY - gal.top) / gal.run, 0, 1);
    if (Math.abs(p - galLast) < 0.0005) return; // unchanged — skip style writes
    galLast = p;
    const n = galItems.length;
    // 0 … n-1: which pair is on top, fractional during a wipe. Each moment holds briefly so scrolling rarely rests mid-wipe
    const raw = p * (n - 1), k = Math.min(n - 2, Math.floor(raw));
    const w = clamp((raw - k - 0.15) / 0.7, 0, 1);
    const pos = k + w * w * (3 - 2 * w);
    galItems.forEach((g, i) => {
      const t = i === 0 ? 1 : clamp(pos - (i - 1), 0, 1); // how far this pair has come in
      const outP = clamp(pos - i, 0, 1); // how far the next pair has covered it
      // The wide shot alternates high/low, so the outgoing pair fades rather than peeking through the gaps
      g.el.style.transform = `scale(${(1 - outP * 0.05).toFixed(4)})`;
      g.el.style.opacity = (1 - clamp((outP - 0.05) / 0.45, 0, 1)).toFixed(3);
      g.figs.forEach((f, j) => {
        const inP = i === 0 ? 1 : clamp((t - j * 0.22) / 0.78, 0, 1); // second photo trails the first
        const r = ((1 - inP) * 100).toFixed(2);
        if (i > 0) f.el.style.clipPath = j ? `inset(0 0 ${r}% 0)` : `inset(${r}% 0 0 0)`; // wipe up, then down
        f.img.style.transform = `scale(${(1.18 - inP * 0.18 + outP * 0.04).toFixed(4)})`;
      });
    });
    galBar.style.transform = `scaleX(${p.toFixed(4)})`;
    const shown = Math.min(n - 1, Math.round(pos));
    if (shown !== galShown) {
      galShown = shown;
      galIdx.textContent = String(shown + 1).padStart(2, "0");
      galTexts.forEach((t, i) => t.classList.toggle("is-active", i === shown));
      galList.forEach((t, i) => t.classList.toggle("is-active", i === shown));
    }
  };

  measure();
  cx = -1; // force first carousel write
  requestAnimationFrame(loop);

  /* ---------- Reveal on scroll ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      e.target.classList.add("in");
      // clip-path'd reveals are observed through their parent (a fully clipped box never "intersects")
      $$(":scope > .img-reveal", e.target).forEach((c) => c.classList.add("in"));
      if (e.target.matches("[data-count]")) countUp(e.target);
      io.unobserve(e.target);
    });
  }, { threshold: 0.15, rootMargin: "0px 0px -8% 0px" });
  $$("[data-split], [data-reveal], #footerWord, [data-count]").forEach((el) => io.observe(el));
  $$(".img-reveal").forEach((el) => io.observe(el.parentElement));

  $$(".about__outro [data-reveal]").forEach((el, i) => el.style.setProperty("--d", i * 0.12 + "s"));

  const countUp = (el) => {
    const end = +el.dataset.count;
    const t0 = performance.now();
    const f = (t) => {
      const p = clamp((t - t0) / 1600, 0, 1);
      el.textContent = Math.round(end * (1 - Math.pow(1 - p, 4)));
      if (p < 1) requestAnimationFrame(f);
    };
    requestAnimationFrame(f);
  };

  /* ---------- Magnetic button ---------- */
  $$("[data-magnetic]").forEach((el) => {
    el.addEventListener("pointermove", (e) => {
      const r = el.getBoundingClientRect();
      el.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.3}px, ${(e.clientY - r.top - r.height / 2) * 0.4}px)`;
    });
    el.addEventListener("pointerleave", () => { el.style.transform = ""; });
  });

  /* ---------- Nav: active link + mobile menu ---------- */
  const links = $$(".nav__links a");
  const secIO = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      // Tall sections (the pinned gallery) never reach 40% visible, so also accept "fills most of the screen"
      if (!e.isIntersecting || (e.intersectionRatio < 0.4 && e.intersectionRect.height < innerHeight * 0.6)) return;
      links.forEach((a) => a.classList.toggle("is-active", a.getAttribute("href") === "#" + e.target.id));
    });
  }, { threshold: [0, 0.2, 0.4, 0.6, 0.8, 1] });
  $$("section[id]").forEach((s) => secIO.observe(s));

  $(".nav__burger").addEventListener("click", () => document.body.classList.toggle("menu-open"));
  $$(".menu a").forEach((a) => a.addEventListener("click", () => document.body.classList.remove("menu-open")));
})();
